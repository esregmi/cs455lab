class UserPlaylist {
  constructor(id, userId, musicId, orderId) {
    this.id = id;
    this.userId = userId;
    this.musicId = musicId;
    this.orderId = orderId;
    this.urlPath = urlPath;
  }
}