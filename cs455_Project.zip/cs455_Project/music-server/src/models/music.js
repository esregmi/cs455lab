class Music {
  constructor(id, title, releaseDate, urlPath) {
    this.id = id;
    this.title = title;
    this.releaseDate = releaseDate;
    this.urlPath = urlPath;
  }
}