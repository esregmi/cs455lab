class User {
  constructor(id, username, email, password, playType) {
    this.id = id;
    this.username = username;
    this.email = email;
    this.password = password;
    this.playType = playType;
  }
}