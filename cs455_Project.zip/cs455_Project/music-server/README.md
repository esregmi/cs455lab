# musicplayer
music player for wap

after checkout run npm install to install all the required packages

This project contains two applications, frontend and backend. 
src folder contains code for server side and public folder contains static frontend code.

data is in js file as an array.
since the password is hashed, you can use 'password' for every user.
